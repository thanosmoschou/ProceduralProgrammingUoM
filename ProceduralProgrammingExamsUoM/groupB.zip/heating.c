#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define M 6
#define HEATERS 4


int main(){
   
   float sysCons[M] = {234.2, 135.4, 222.4, 90.4, 340.4, 310.0};
   int sysBTU[M] = {2000, 1500, 3000, 2500, 4000, 3500};
   int sysCode[M] = {1222,1344,2234,5556,2221,3334};
   char sysBrand[M][15] = {"FumitsuA", "Noheat","FumitsuB","Varrier","TokibaA", "TokibaB"};

   int building[HEATERS] = {1222,1344,2234,3334};

   return 0;
}


